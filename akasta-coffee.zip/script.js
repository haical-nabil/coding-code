/* ==========================================================================
   AKASTA — script.js
   Four small, independent features. Each is wrapped in its own function
   and guarded so a missing element never breaks the others.
   ========================================================================== */

document.addEventListener('DOMContentLoaded', () => {
  initStickyHeader();
  initScrollSpy();
  initMobileNavAutoClose();
  initTestimonialSlider();
  initGalleryLightbox();
});


/* --------------------------------------------------------------------------
   1. Sticky header — solidifies once the hero has been scrolled past
   -------------------------------------------------------------------------- */
function initStickyHeader() {
  const header = document.querySelector('.site-header');
  if (!header) return;

  const setState = () => {
    header.classList.toggle('is-scrolled', window.scrollY > 60);
  };

  setState();
  window.addEventListener('scroll', setState, { passive: true });
}


/* --------------------------------------------------------------------------
   2. Scroll-spy navigation — highlights the nav link for the section
      currently in view
   -------------------------------------------------------------------------- */
function initScrollSpy() {
  const navLinks = Array.from(document.querySelectorAll('.main-nav a[href^="#"]'));
  if (!navLinks.length) return;

  const sections = navLinks
    .map(link => document.querySelector(link.getAttribute('href')))
    .filter(Boolean);

  if (!sections.length || !('IntersectionObserver' in window)) return;

  const linkFor = (id) => navLinks.find(link => link.getAttribute('href') === `#${id}`);

  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      const link = linkFor(entry.target.id);
      if (!link) return;
      if (entry.isIntersecting) {
        navLinks.forEach(l => {
          l.classList.remove('active');
          l.removeAttribute('aria-current');
        });
        link.classList.add('active');
        link.setAttribute('aria-current', 'true');
      }
    });
  }, {
    // Treat a section as "active" once it occupies the vertical centre
    // of the viewport, accounting for the fixed header height.
    rootMargin: '-45% 0px -50% 0px',
    threshold: 0
  });

  sections.forEach(section => observer.observe(section));
}


/* --------------------------------------------------------------------------
   Mobile nav — auto-close the CSS checkbox menu after a link is tapped
   -------------------------------------------------------------------------- */
function initMobileNavAutoClose() {
  const toggle = document.getElementById('nav-toggle');
  const label = document.querySelector('.nav-toggle-label');
  const links = document.querySelectorAll('.main-nav a');
  if (!toggle) return;

  const syncExpanded = () => {
    if (label) label.setAttribute('aria-expanded', String(toggle.checked));
  };

  toggle.addEventListener('change', syncExpanded);

  links.forEach(link => {
    link.addEventListener('click', () => {
      toggle.checked = false;
      syncExpanded();
    });
  });
}


/* --------------------------------------------------------------------------
   3. Testimonial slider — autoplay, dot navigation, prev/next controls,
      pauses on hover/focus, supports arrow keys
   -------------------------------------------------------------------------- */
function initTestimonialSlider() {
  const slider = document.querySelector('.testimonial-slider');
  if (!slider) return;

  const track = slider.querySelector('.testimonial-track');
  const cards = Array.from(slider.querySelectorAll('.testimonial-card'));
  const dotsWrap = slider.querySelector('[data-testimonial-dots]');
  const prevBtn = slider.querySelector('[data-testimonial-prev]');
  const nextBtn = slider.querySelector('[data-testimonial-next]');
  if (!track || !cards.length) return;

  let index = 0;
  const autoplayDelay = parseInt(slider.dataset.autoplay, 10) || 6000;
  let timer = null;

  // Build one dot per testimonial
  const dots = cards.map((_, i) => {
    const dot = document.createElement('button');
    dot.type = 'button';
    dot.className = 'testimonial-dot';
    dot.setAttribute('aria-label', `Testimoni ${i + 1}`);
    dot.addEventListener('click', () => goTo(i));
    dotsWrap.appendChild(dot);
    return dot;
  });

  function render() {
    track.style.transform = `translateX(-${index * 100}%)`;
    dots.forEach((dot, i) => dot.classList.toggle('is-active', i === index));
  }

  function goTo(i) {
    index = (i + cards.length) % cards.length;
    render();
  }

  function next() { goTo(index + 1); }
  function prev() { goTo(index - 1); }

  function startAutoplay() {
    stopAutoplay();
    timer = setInterval(next, autoplayDelay);
  }
  function stopAutoplay() {
    if (timer) clearInterval(timer);
  }

  if (nextBtn) nextBtn.addEventListener('click', () => { next(); startAutoplay(); });
  if (prevBtn) prevBtn.addEventListener('click', () => { prev(); startAutoplay(); });

  slider.addEventListener('mouseenter', stopAutoplay);
  slider.addEventListener('mouseleave', startAutoplay);
  slider.addEventListener('focusin', stopAutoplay);
  slider.addEventListener('focusout', startAutoplay);

  slider.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowRight') { next(); startAutoplay(); }
    if (e.key === 'ArrowLeft') { prev(); startAutoplay(); }
  });

  render();
  startAutoplay();
}


/* --------------------------------------------------------------------------
   4. Gallery lightbox — opens a larger view of any gallery photo with
      keyboard, click-outside and prev/next support
   -------------------------------------------------------------------------- */
function initGalleryLightbox() {
  const lightbox = document.getElementById('lightbox');
  const triggers = Array.from(document.querySelectorAll('.gallery-trigger'));
  if (!lightbox || !triggers.length) return;

  const imageEl = document.getElementById('lightbox-image');
  const captionEl = document.getElementById('lightbox-caption');
  const closeBtn = lightbox.querySelector('[data-lightbox-close]');
  const prevBtn = lightbox.querySelector('[data-lightbox-prev]');
  const nextBtn = lightbox.querySelector('[data-lightbox-next]');

  const photos = triggers.map(trigger => {
    const img = trigger.querySelector('img');
    return { src: img.src, alt: img.alt };
  });

  let current = 0;
  let lastFocused = null;

  function show(i) {
    current = (i + photos.length) % photos.length;
    const photo = photos[current];
    imageEl.src = photo.src;
    imageEl.alt = photo.alt;
    captionEl.textContent = photo.alt;
  }

  function open(i) {
    lastFocused = document.activeElement;
    show(i);
    lightbox.hidden = false;
    // Allow the browser to paint before transitioning in
    requestAnimationFrame(() => lightbox.classList.add('is-open'));
    document.body.classList.add('lightbox-locked');
    closeBtn.focus();
    document.addEventListener('keydown', onKeydown);
  }

  function close() {
    lightbox.classList.remove('is-open');
    document.body.classList.remove('lightbox-locked');
    document.removeEventListener('keydown', onKeydown);
    // Wait for the fade-out transition before hiding from the a11y tree
    setTimeout(() => { lightbox.hidden = true; }, 250);
    if (lastFocused) lastFocused.focus();
  }

  function onKeydown(e) {
    if (e.key === 'Escape') close();
    if (e.key === 'ArrowRight') show(current + 1);
    if (e.key === 'ArrowLeft') show(current - 1);
  }

  triggers.forEach((trigger, i) => {
    trigger.addEventListener('click', () => open(i));
  });

  closeBtn.addEventListener('click', close);
  nextBtn.addEventListener('click', () => show(current + 1));
  prevBtn.addEventListener('click', () => show(current - 1));

  // Click outside the figure (on the dark backdrop) closes the lightbox
  lightbox.addEventListener('click', (e) => {
    if (e.target === lightbox) close();
  });
}
